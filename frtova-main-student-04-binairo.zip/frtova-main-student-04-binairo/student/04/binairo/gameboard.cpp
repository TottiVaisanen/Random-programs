/* Program Authors
*
* Name: Totti Väisänen
* Student Number: 151364051
* Username: frtova (Git repository directory name)
* E-Mail: totti.vaisanen@tuni.fi
*
* Name: Jella Vaara
* Student Number: 152043355
* Username: gkjeva
* E-mail: jella.vaara@tuni.fi
* */

#include "gameboard.hh"
#include <iostream>
#include <random>
#include <algorithm>

GameBoard::GameBoard()

{

}

bool GameBoard::create_random(std::string seed){
    // First check if the seed is good.
    unsigned int number = std::stoi(seed);
    auto it = std::find(BAD_SEEDS.begin(), BAD_SEEDS.end(), number);

    // If seed isn't a bad seed we can continue
    if (it == BAD_SEEDS.end()){

        std::default_random_engine gen(number);
        std::uniform_int_distribution<int> distr(0, 10);

        // Creating all the vectors for each row
        std::string::size_type counter = 0;
        while (counter < SIZE) {
            std::vector<Element_type> row;
            board_.insert(board_.end(), row);
            ++counter;
        }

        // Now we add a random element to each row
        int counter2 = 0;
        for (std::vector<Element_type>& row : board_) {
            int low_limit = counter2 * SIZE;
            int upper_limit = counter2 * SIZE + SIZE;
            int c = low_limit;

            while (c < upper_limit and c >= low_limit) {
                // Randomizing the number
                auto i = distr(gen);
                // Adding the random to the row
                if (i == 0) {
                    row.push_back(ZERO);
                } else if (i == 1) {
                    row.push_back(ONE);
                } else {
                    row.push_back(EMPTY);
                }
                ++c;
            }
            ++counter2;
        }


    // If it is a bad seed we return fales
    } else {
        std::cout << "Bad seed" << std::endl;
        return false;
    } return true;
}

bool GameBoard::is_game_over(){

    // Checking each row and each element
    // There should be SIZE/2 amount of ones and zeroes.
    int zero_counter = 0;
    int one_counter = 0;
    for (const auto& row : board_) {

        for (const auto& element : row){
            if (element == EMPTY){
                return false;
            } else if (element == ONE){
                one_counter += 1;
            } else if (element == ZERO){
                zero_counter += 1;
            }
        }

    }
    if (zero_counter == (SIZE*SIZE)/2 and one_counter == (SIZE*SIZE)/2){
        return true;
    } else{
        return false;
    }
}

bool GameBoard::create(std::string input) {

    // If input doesn't pass the test we automatically return false
    if (!check_input(input)) {
        return false;

    // else we continue
    } else {
        std::string real_input = input.substr(1, input.size() - 2);

        // We add a vector for each row on the board
        std::string::size_type counter = 0;
        while (counter < SIZE) {
            std::vector<Element_type> row;
            board_.insert(board_.end(), row);
            ++counter;
        }

        // Now we add the according elements to each slot on each row
        // The counter helps us keep track which row it is
        int counter2 = 0;

        // Looping through each row
        for (std::vector<Element_type>& row : board_) {

            // We set lower and upper limit so we use the right spot of the input
            int low_limit = counter2 * SIZE;
            int upper_limit = counter2 * SIZE + SIZE;
            int c = low_limit;

            // Looping through the right part of the input and adding each element to the row
            while (c < upper_limit and c >= low_limit) {
                char i = real_input.at(c);
                if (i == ' ') {
                    row.push_back(EMPTY);
                } else if (i == '1') {
                    row.push_back(ONE);
                } else {
                    row.push_back(ZERO);
                }
                ++c;
            }
            ++counter2;
        }
    }
    return true;
}

bool GameBoard::check_input(std::string input) {
    std::string real_input = input.substr(1, input.size() - 2);
    if (input.size() - 2 != 36) {
        std::cout << "Wrong size of input" << std::endl;
        return false;
    }
    for (char i : real_input) {
        if (i != '0' && i != '1' && i != ' ') {
            std::cout << "Wrong character" << std::endl;
            return false;
        }
    }
    return true;
}

void GameBoard::print() const
{
    // Printing upper border
    print_line(LEFT_COLUMN_WIDTH + 1 + 2 * SIZE + 1, '=');

    // Printing title row
    std::cout << "|   | ";
    for(unsigned int i = 0; i < SIZE; ++i)
    {
        std::cout << i + 1 << " ";
    }
    std::cout << "|" << std::endl;

    // Printing line after the title row
    print_line(LEFT_COLUMN_WIDTH + 1 + 2 * SIZE + 1, '-');

    // Printing the actual content of the gameboard

    for(unsigned int i = 0; i < SIZE; ++i)
    {
        std::cout << "| " << i + 1 << " | ";

        std::vector<Element_type> the_vector = board_.at(i);

        int counter = 0;
            // We go through every every element and print it at the end of the row
            while (counter < SIZE) {

                if (the_vector.at(counter) == EMPTY) {
                    std::cout<< "  ";
                } else if (the_vector.at(counter) == ONE ){
                    std::cout<< "1 ";
                } else {
                    std::cout << "0 ";
                }
            counter += 1;

        }
        std::cout << "|" << std::endl;
    }
    // Printing lower border
    print_line(LEFT_COLUMN_WIDTH + 1 + 2 * SIZE + 1, '=');
}

void GameBoard::print_line(unsigned int length, char fill_character) const
{
    for(unsigned int i = 0; i < length; ++i)
    {
        std::cout << fill_character;
    }
    std::cout << std::endl;
}

bool GameBoard::add(int x, int y, std::string input) {

    // Add the input if the board is empty in that spot
    if (board_[y-1][x-1] != EMPTY){

        std::cout << "Can't add" << std::endl;
        return false;

    } else{

        if (input == "1"){
            board_[y-1][x-1] = ONE;
        } else{
            board_[y-1][x-1] = ZERO;
        }

        // Now we check that the add was okay
        if (check_gameboard() == false) {
            board_[y-1][x-1] = EMPTY;
            std::cout << "Can't add" << std::endl;
            return false;
        }

        return true;
    }
}

// Function checks that the gameboard is okay. Such as you can't have more than half of the same
// marks on the same row and column.
bool GameBoard::check_gameboard() {

    int max = SIZE/2;
    // Counters to check that there are only max 3 of the same numbers
    // on the row.
    int counter_1 = 0;
    int counter_0 = 0;

    // Counters to check that there are only max 2 same numbers in a row.
    // when the other one has one added the other's value is set to 0.
    int chain_1 = 0;
    int chain_0 = 0;

    // Let's go through each row and see that it doesn't have too many of 0s or 1s
    for (std::vector<Element_type>& row : board_) {

        // Now we go through each element on the row
        for (Element_type e : row ) {

            if ( e == ONE ){
                chain_0 = 0;
                chain_1 += 1;
                if(chain_1 == 3){
                    return false;
                }
                ++counter_1;
            } else if ( e == ZERO ){
                chain_1 = 0;
                chain_0 += 1;
                if(chain_0 == 3){
                    return false;
                }
                ++counter_0;
            } else {
                chain_1 = 0;
                chain_0 = 0;
            }
        }

        // A check that they don't have too many same numbers on row
        if (counter_1 > max or counter_0 > max) {
            return false;
        }

        // Now we reset the counters for next row
        counter_1 = 0;
        counter_0 = 0;
        chain_1 = 0;
        chain_0 = 0;
    }

    int counter1 = 0;
    int counter0 = 0;

    int chain1 = 0;
    int chain0 = 0;

    // Now we go through each column
    // First we loop through the j (which are columns)
    for (int j = 0; j < SIZE; ++j) {

        // Now we loop through the i (which are rows)
        for ( int i = 0; i < SIZE; ++i ) {

            if (board_[i][j] == ONE) {
                chain0 = 0;
                chain1 += 1;
                if(chain1 == 3){
                    return false;
                }
                ++counter1;
            } else if (board_[i][j] == ZERO) {
                chain1 = 0;
                chain0 += 1;
                if(chain0 == 3){
                    return false;
                }
                ++counter0;
            } else {
                chain0 = 0;
                chain1 = 0;
            }
        }

        // Also a check that there aren't too many same numbers on same column
        if (counter1 > max or counter0 > max) {
            return false;
        }

        // Reset the counters for next column
        counter1 = 0;
        counter0 = 0;
        chain0 = 0;
        chain1 = 0;

    }

    // If all goes well we return true
    return true;
}
