/*
 * Description:
 * The program implements the Binairo game. The game consists of a 6 x 6 grid.
 * Each square contains zero, one, or is empty. The goal is to add zeros and ones
 * to the empty squares according to the following rules:
 * - Each horizontal and vertical row may have at most three of the same number
 * - Each horizontal and vertical row may have at most two consecutive identical numbers.
 * Initially, the user is asked whether to fill the grid with randomly
 * generated symbols or with 36 symbols chosen by the user.
 * In the first option, the user is asked for a random number
 * generator seed, and in the second, the user is asked to enter
 * 36 symbols, which are then validated.
 * On each round, the user is asked for the coordinates of the added symbol
 * and the symbol to be added, a total of three symbols. The game ends in victory
 * if the grid has been filled according to the aforementioned rules. The program
 * does not allow additions that violate the aforementioned rules, but it is possible
 * to reach a situation where no further additions are possible.
 * The program validates the inputs provided. The symbol to be added must be
 * zero or one. The coordinates must be within the grid, and the square indicated
 * by them must be empty.
 *
 * Program Authors
 *
 * Name: Totti Väisänen
 * Student Number: 151364051
 * Username: frtova (Git repository directory name)
 * E-Mail: totti.vaisanen@tuni.fi
 *
 * Name: Jella Vaara
 * Student Number: 152043355
 * Username: gkjeva
 * E-mail: jella.vaara@tuni.fi
 *
 * Notes on the program and its implementation:
 * -
 * */
#include "gameboard.hh"
#include <iostream>

using namespace std;

// Output messages
const string QUIT = "Quitting ...";
const string OUT_OF_BOARD = "Out of board";
const string INVALID_INPUT = "Invalid input";
const string CANT_ADD = "Can't add";
const string WIN = "You won!";


// Converts the given numeric string to the corresponding integer
// (by calling stoi) and returns the integer.
// If the given string is not numeric, returns zero.
unsigned int stoi_with_check(const string& str)
{
    bool is_numeric = true;
    for(unsigned int i = 0; i < str.length(); ++i)
    {
        if(not isdigit(str.at(i)))
        {
            is_numeric = false;
            break;
        }
    }
    if(is_numeric)
    {
        return stoi(str);
    }
    else
    {
        return 0;
    }
}

// Removes empty characters (such as ' ' etc.) from the given string.
// Returns true if the given string has exactly one non-empty character,
// which is either '0' or '1', otherwise returns false.
bool find_fill_symbol(string& str)
{
    string fill_str = "";
    for(unsigned int i = 0; i < str.size(); ++i)
    {
        if(not isspace(str.at(i)))
        {
            fill_str += str.at(i);
        }
    }
    str = fill_str;
    return (fill_str.size() == 1 and
           (fill_str.at(0) == '0' or fill_str.at(0) == '1'));
}

// Enables the user to play the game, i.e. by repeatedly asking an element
// to be added and its position, until the game is over.
void play_game(GameBoard& board)
{
    board.print();
    while(not board.is_game_over())
    {
        string x_str = "";
        string y_str = "";
        string rest_input = "";
        cout << "Enter two coordinates and a fill symbol, or q to quit: ";

        // Reading x coordinate as a string and checking if it was quit command
        cin >> x_str;
        if(x_str.at(0) == 'q' or x_str.at(0) == 'Q')
        {
            cout << QUIT << endl;
            return;
        }

        // Reading y coordinate
        cin >> y_str;

        // Changing coordinates from string to int and checking if they are
        // inside the board
        unsigned int x = stoi_with_check(x_str);
        unsigned int y = stoi_with_check(y_str);
        if(not (1 <= x and x <= SIZE and 1 <= y and y <= SIZE))
        {
            cout << OUT_OF_BOARD << endl;
            getline(cin, rest_input);
            continue;
        }

        // Reading the rest of the input line including fill symbol and
        // checking if the rest input consists exactly of one '0' or '1'
        getline(cin, rest_input);
        if(not find_fill_symbol(rest_input))
        {
            cout << INVALID_INPUT << endl;
            continue;
        }

        // At this point, we know that the input is valid, but we don't know
        // if it is possible to add the given symbol on the given position.
        // If the position is availble, add it to the board and print it.

        if(board.add(x, y, rest_input)){
            board.print();
        }




    }
    // If the game ends up to a totally filled gameboard, the player won
    cout << WIN << endl;
}

// Gives the user a possibility to select a filling way.
// Returns true if filling succeeded, otherwise returns false.
bool select_start(GameBoard& board)
{
    string choice = "";
    cout << "Select start (R for random, I for input): ";
    getline(cin, choice);
    if(choice != "R" and choice != "r" and choice != "I" and choice != "i")
    {
        return false;
    }
    else if(choice == "R" or choice == "r")
    {
        string seed_string = "";
        cout << "Enter a seed value: ";
        getline(cin, seed_string);

        return board.create_random(seed_string);


    }
    else // if(choice == "I" or choice == "i")
    {
        string input = "";
        cout << "Input: ";
        getline(cin, input);

        // (Note that at this point, input includes quote marks or such)
        // Fill gameboard and return if it succeeded or not

        return board.create(input);

    }
}


// Short and simple main function.
int main()
{
    GameBoard board;
    while(not select_start(board));
                                    // no code to be repeated
    play_game(board);
    return 0;
}
