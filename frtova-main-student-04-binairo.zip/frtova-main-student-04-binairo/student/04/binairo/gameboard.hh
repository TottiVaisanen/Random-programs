/* Program Authors
*
* Name: Totti Väisänen
* Student Number: 151364051
* Username: frtova (Git repository directory name)
* E-Mail: totti.vaisanen@tuni.fi
*
* Name: Jella Vaara
* Student Number: 152043355
* Username: gkjeva
* E-mail: jella.vaara@tuni.fi
* */

#ifndef GAMEBOARD_HH
#define GAMEBOARD_HH

#include <vector>
#include <string>

// Type of the elements in the gameboard.
enum Element_type {ZERO, ONE, EMPTY};


// Constants for the size of the gameboard.
const int NUMBER_OF_SYMBOLS = 3;
const int SIZE = 2 * NUMBER_OF_SYMBOLS;

// Constant for the upper bound of probability distribution.
// Zeros and ones have the same probability, say x, and the estimated
// probability of empties is 6x, whereupon their sum is 8x, and thus,
// the interval must have eigth points, as [0..7].
const int DISTR_UPPER_BOUND = 7;

// Width of the left-most column, needed in printing the gameboard.
const unsigned int LEFT_COLUMN_WIDTH = 5;


class GameBoard
{
public:
    // Constructor.
    GameBoard();

    // Prints the gameboard.
    void print() const;

    // Creates the gameboard randomly.
    bool create_random(std::string seed);

    // Creates the gameboard with the given input.
    bool create(std::string);

    // Checks if the board is filled out.
    bool is_game_over();

    // Checks if the given input 0 or 1 can be added to its place
    // and adds it if possible
    bool add(int x, int y, std::string c);

    // Checks that there are only SIZE/2 amount of the same number
    // on the same row and on the same column.
    bool check_gameboard();

private:

    // Checks that the given input is correct
    bool check_input(std::string input);

    // Prints a line with the given length and the given character.
    void print_line(unsigned int length, char fill_character) const;

    // Seed values, from [1..50], producing non-solvable gameboard.
    const std::vector<unsigned int> BAD_SEEDS = { 2, 8, 12, 13, 16, 20, 21, 23,
                                                  26, 29, 31, 32, 34, 41, 42,
                                                  43, 44, 46 };

    // Vector that is made out of vectors that represent the rows.
    // Each row is made out of elements that are ZERO, ONE or empty.
    std::vector<std::vector<Element_type>> board_;
};


#endif // GAMEBOARD_HH
